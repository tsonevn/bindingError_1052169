"use strict";
var observable_1 = require("data/observable");
var frame_1 = require('ui/frame');
var viewModel = (function (_super) {
    __extends(viewModel, _super);
    function viewModel(page) {
        _super.call(this);
        this.page = page;
    }
    viewModel.prototype.backTap = function () {
        frame_1.topmost().goBack();
    };
    ;
    return viewModel;
}(observable_1.Observable));
exports.viewModel = viewModel;
function pageLoaded(args) {
    var page = args.object;
    page.bindingContext = new viewModel(page);
}
exports.pageLoaded = pageLoaded;
;
//# sourceMappingURL=testform.js.map
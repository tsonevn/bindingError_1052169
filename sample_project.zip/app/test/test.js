"use strict";
var observable_1 = require("data/observable");
var observable_array_1 = require("data/observable-array");
var frame_1 = require('ui/frame');
var viewModel = (function (_super) {
    __extends(viewModel, _super);
    function viewModel(page) {
        _super.call(this);
        this.page = null;
        this.data = [
            { description: "aaa" },
            { description: "bbb" },
            { description: "ccc" },
        ];
        this.formTap = function () {
            frame_1.topmost().navigate({ moduleName: "testform/testform" });
        };
        this.page = page;
        this.set("rows1", new observable_array_1.ObservableArray());
        this.set("rows2", new observable_array_1.ObservableArray());
    }
    viewModel.prototype.tabChanged = function (args) {
        switch (args.newIndex) {
            case 0:
                break;
            case 1:
                this.set("rows1", new observable_array_1.ObservableArray(this.data));
                break;
            case 2:
                this.set("rows2", new observable_array_1.ObservableArray(this.data));
                break;
        }
    };
    ;
    return viewModel;
}(observable_1.Observable));
exports.viewModel = viewModel;
function pageLoaded(args) {
    var page = args.object;
    page.bindingContext = new viewModel(page);
}
exports.pageLoaded = pageLoaded;
;
//# sourceMappingURL=test.js.map
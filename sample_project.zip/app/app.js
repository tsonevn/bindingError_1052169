var application = require("application");
application.start({ moduleName: "test/test" });
